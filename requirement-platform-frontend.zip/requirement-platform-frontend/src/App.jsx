import NewProject from "./pages/NewProject";

function App() {
  return <NewProject />;
}

export default App;
