import "../App.css";

function Architecture() {
  return (
    <div className="page-container">
      <div className="card">
        <h2>System Architecture</h2>

        <h3>Three-Layer Architecture</h3>

        <ul>
          <li><strong>Presentation Layer:</strong> React frontend</li>
          <li><strong>Application Layer:</strong> Node.js & Express API</li>
          <li><strong>Data Layer:</strong> MongoDB Database</li>
        </ul>

        <h3>Execution Flow</h3>
        <ol>
          <li>User submits project data.</li>
          <li>Frontend sends POST request to backend.</li>
          <li>Backend applies cost estimation logic.</li>
          <li>Data is stored in MongoDB.</li>
          <li>Response returned to frontend.</li>
        </ol>

        <h3>Scalability Considerations</h3>
        <p>
          The modular design allows future integration of
          machine learning-based estimation models and
          visual diagram generation tools.
        </p>
      </div>
    </div>
  );
}

export default Architecture;
