import "../App.css";

function Methodology() {
  return (
    <>
      <div className="page-header">
        <h1>Development Methodology</h1>
        <p>Technology Stack & Implementation Strategy</p>
      </div>

      <div className="page-container">

        <div className="section-block">
          <h2>Frontend</h2>
          <ul>
            <li>React (Component-based architecture)</li>
            <li>State management using React Hooks</li>
            <li>Responsive UI design</li>
          </ul>
        </div>

        <div className="section-block">
          <h2>Backend</h2>
          <ul>
            <li>Node.js & Express</li>
            <li>RESTful API design</li>
            <li>Service-based cost estimation logic</li>
          </ul>
        </div>

        <div className="section-block">
          <h2>Database</h2>
          <ul>
            <li>MongoDB Atlas</li>
            <li>Document-based storage</li>
            <li>Persistent project records</li>
          </ul>
        </div>

      </div>
    </>
  );
}

export default Methodology;
