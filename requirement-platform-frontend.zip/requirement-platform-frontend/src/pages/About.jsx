import "../App.css";

function About() {
  return (
    <div className="page-container">
      <div className="card">
        <h2>About This Project</h2>

        <p>
          The Automated Requirement and Cost Estimation Platform (ARCEP) 
          is a full-stack web application developed to assist stakeholders 
          in early-stage software project planning.
        </p>

        <p>
          The system generates structured requirements, cost estimation, 
          and logical system flow representation based on user inputs.
        </p>

        <hr style={{ margin: "30px 0" }} />

        <h3>Developed By</h3>

        <p>
          <strong>Ghazanfar Ayyaz</strong><br/>
          MSc Computer Science<br/>
          University of Law
        </p>

        <p>
          This project demonstrates full-stack development using 
          React, Node.js, Express, and MongoDB.
        </p>
      </div>
    </div>
  );
}

export default About;
