import "../App.css";

function Requirements() {
  return (
    <>
      <div className="page-header">
        <h1>System Requirements & Flow</h1>
        <p>Functional, Non-Functional Requirements and System Execution Flow</p>
      </div>

      <div className="page-container">

        <div className="section-block">
          <h2>Functional Requirements</h2>
          <ul>
            <li>Users can input project details (type, pages, features).</li>
            <li>System calculates estimated development cost.</li>
            <li>System generates structured system flow.</li>
            <li>Project data is stored in MongoDB.</li>
            <li>Users can submit contact messages.</li>
          </ul>
        </div>

        <div className="section-block">
          <h2>Non-Functional Requirements</h2>
          <ul>
            <li>Responsive web interface.</li>
            <li>Secure RESTful API communication.</li>
            <li>Scalable and modular architecture.</li>
            <li>Reliable cost estimation logic.</li>
          </ul>
        </div>

        <div className="section-block">
          <h2>System Flow Diagram</h2>

          <div className="flow-container">
            <div className="flow-box">User Inputs Project Details</div>
            <div className="arrow">↓</div>
            <div className="flow-box">React Frontend Sends Data</div>
            <div className="arrow">↓</div>
            <div className="flow-box">Node.js Backend Processes Data</div>
            <div className="arrow">↓</div>
            <div className="flow-box">Cost Estimation Logic Applied</div>
            <div className="arrow">↓</div>
            <div className="flow-box">MongoDB Stores Project</div>
            <div className="arrow">↓</div>
            <div className="flow-box">Estimated Cost Returned to User</div>
          </div>

        </div>

      </div>
    </>
  );
}

export default Requirements;
