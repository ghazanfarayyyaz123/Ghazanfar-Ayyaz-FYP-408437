import { useState, useEffect } from "react";
import "../App.css";

function NewProject() {

  const [projectName, setProjectName] = useState("");
  const [projectType, setProjectType] = useState("Simple Website");
  const [pages, setPages] = useState(5);
  const [features, setFeatures] = useState([]);
  const [result, setResult] = useState(null);
  const [animatedCost, setAnimatedCost] = useState(0);

  const handleFeatureChange = (feature) => {
    if (features.includes(feature)) {
      setFeatures(features.filter((f) => f !== feature));
    } else {
      setFeatures([...features, feature]);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const response = await fetch("http://localhost:5000/api/projects", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        projectName,
        projectType,
        pages,
        features
      })
    });

    const data = await response.json();
    setResult(data);
  };

  /* 🎯 Animated Cost Counter */
  useEffect(() => {
    if (result) {
      let start = 0;
      const end = result.estimatedCost;
      const duration = 1200;
      const increment = end / 60;

      const counter = setInterval(() => {
        start += increment;
        if (start >= end) {
          start = end;
          clearInterval(counter);
        }
        setAnimatedCost(Math.floor(start));
      }, duration / 60);
    }
  }, [result]);

  return (
    <>
      <div className="hero">
        <h1>Automated Requirement & Cost Estimator</h1>
        <p>
          Generate structured plans, system flows and development cost estimates instantly.
        </p>
      </div>

      <div className="container">

        <div className="highlight-box">
          <strong>Intelligent Cost Prediction:</strong> 
          Rule-based estimation engine powered by automated requirement analysis.
        </div>

        <div className="card">
          <h3>Project Details</h3>

          <form onSubmit={handleSubmit}>

            <label>Project Name</label>
            <input
              type="text"
              value={projectName}
              onChange={(e) => setProjectName(e.target.value)}
              required
            />

            <label>Project Type</label>
            <select
              value={projectType}
              onChange={(e) => setProjectType(e.target.value)}
            >
              <option>Simple Website</option>
              <option>E-Commerce</option>
              <option>Enterprise System</option>
            </select>

            <label>Number of Pages / Screens</label>
            <input
              type="number"
              value={pages}
              onChange={(e) => setPages(e.target.value)}
            />

            <label>Features</label>

            <div className="feature-box">
              <label>
                <input
                  type="checkbox"
                  onChange={() => handleFeatureChange("authentication")}
                />
                User Authentication
              </label>

              <label>
                <input
                  type="checkbox"
                  onChange={() => handleFeatureChange("payment")}
                />
                Payment Gateway
              </label>

              <label>
                <input
                  type="checkbox"
                  onChange={() => handleFeatureChange("admin")}
                />
                Admin Panel
              </label>
            </div>

            <button type="submit" className="generate-btn">
              Generate Plan & Cost
            </button>

          </form>
        </div>

        {result && (
          <div className="card result-card">
            <h3>Estimated Cost</h3>
            <div className="cost-box">
              £{animatedCost}
            </div>

            <h4>System Flow</h4>
            <pre className="flow-box">
              {JSON.stringify(result.flow, null, 2)}
            </pre>
          </div>
        )}

      </div>
    </>
  );
}

export default NewProject;
